<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  <ul class="nav navbar-nav">
      <li>
          <a href="{!!URL::to('index')!!}">Menú principal</a>
      </li>
      <li>
          <a href="{!!URL::to('nurseSheet/create')!!}">Crear HDE</a>
      </li>
      <li>
          <a href="{!!URL::to('nurseSheet/deleter')!!}">Eliminar HDE</a>
      </li>
      <li>
          <a href="{!!URL::to('nurseSheet/actualizar')!!}">Actualizar HDE</a>
      </li>
      <li>
          <a href="{!!URL::to('nurseSheet/show')!!}">Mostrar HDE</a>
      </li>
  </ul>
</div>
