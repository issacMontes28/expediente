<div id="modal_habitus">
<div class="form-group">
  {!!Form::label('condición_1','Condición:')!!}
  <input id="condicion" class="form-control"></input>
</div>
<div class="form-group">
{!!Form::label('constitucion_1','Constitucion:')!!}
<input id="constitucion"  type="text" class="form-control"></input>
</div>
<div class="form-group">
{!!Form::label('entereza_1','Entereza:')!!}
<input id="entereza"  type="text" class="form-control"></input>
</div>
<div class="form-group">
{!!Form::label('proporcion_1','Proporción:')!!}
<input id="proporcion"  type="text" class="form-control"></input>
</div>
<div class="form-group">
{!!Form::label('simetria_1','Simetría:')!!}
<input id="simetria"  type="text" class="form-control"></input>
</div>
<div class="form-group">
  {!!Form::label('biotipo_1','Biotipo:')!!}
  <input id="biotipo"  type="text" class="form-control"></input>
</div>
<div class="form-group">
  {!!Form::label('actitud_1','Actitud:')!!}
  <input id="actitud"  type="text" class="form-control"></input>
</div>
<div class="form-group">
  {!!Form::label('fascies_1','Fascies:')!!}
  <input id="fascies"  type="text" class="form-control"></input>
</div>
<div class="form-group">
  {!!Form::label('movanormal_1','Movimientos anormales:')!!}
  <input id="movanormal"  type="text" class="form-control"></input>
</div>
<div class="form-group">
  {!!Form::label('movanormal_obs_1','Observaciones de movimientos anormales:')!!}
  <input id="movanormal_obs"  type="text" class="form-control"></input>
</div>
<div class="form-group">
  {!!Form::label('marchanormal_1','Marchas anormales:')!!}
  <input id="marchanormal"  type="text" class="form-control"></input>
</div>
<div class="form-group">
   <button id="btnAgregar2" type="submit" class="btn btn-primary btn-sm" Onclick="modifyPacient();">
   Modificar HDE</button>
</div>
</div>
