<div class="form-group" align="center">
  <button id="btnsomatometry" class="btn btn-info btn-sm">Somatometría</button>
  <button id="btnhabitus" class="btn btn-info btn-sm">Hábitus exterior</button>
  <button type="submit" onclick="return confirm('¿Realmente desea eliminar estudio?')"
  class="btn btn-info btn-sm">Medicamentos administrados</button>
  <button type="submit" onclick="return confirm('¿Realmente desea eliminar estudio?')"
  class="btn btn-info btn-sm">Medicamentos actuales</button>
</div>
